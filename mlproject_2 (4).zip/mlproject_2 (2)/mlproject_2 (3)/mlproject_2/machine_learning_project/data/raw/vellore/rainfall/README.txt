Vellore Rainfall Data

Station:
IMD Vellore, Station ID 43303

Climatological period:
1991-2020

Annual mean rainfall:
1050.1 mm

Annual mean rainy days:
56.0 days

Highest monthly mean rainfall:
September - 183.8 mm

Historical maximum 24-hour rainfall in the displayed IMD record:
73.4 mm on 20-Sep-2011

Historical maximum monthly rainfall in the displayed IMD record:
286.1 mm in August 2017

Source:
India Meteorological Department (IMD), Vellore station climate/extreme rainfall data.

Note:
The above values are climatological/extreme rainfall statistics and are NOT directly used as an SWMM time series. A time-distributed design storm/rainfall series must be defined separately.