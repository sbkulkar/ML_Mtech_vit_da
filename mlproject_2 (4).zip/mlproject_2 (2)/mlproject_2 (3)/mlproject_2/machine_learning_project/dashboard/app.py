
import streamlit as st
import pandas as pd
from pathlib import Path


# ============================================================
# PAGE CONFIGURATION
# ============================================================

st.set_page_config(
    page_title="Urban Flood Control Dashboard",
    page_icon="🌊",
    layout="wide",
    initial_sidebar_state="expanded"
)


# ============================================================
# PROJECT PATH
# ============================================================

# app.py is inside:
# machine_learning_project/dashboard/
#
# Therefore:
# parents[1] = machine_learning_project

PROJECT_DIR = Path(__file__).resolve().parents[1]

RESULTS_DIR = PROJECT_DIR / "results"


# ============================================================
# CITY / REGION CONFIGURATION
# ============================================================

def normalize_chennai(df: pd.DataFrame) -> pd.DataFrame:

    required_columns = [
        "Storm",
        "Baseline Flood",
        "PPO Flood",
        "Reduction",
        "PPO Depth",
        "Pump Use"
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            "Chennai results file is missing columns: "
            f"{missing_columns}. "
            f"Found: {list(df.columns)}"
        )

    out = df[required_columns].copy()

    # Clean storm names
    out["Storm"] = (
        out["Storm"]
        .astype(str)
        .str.upper()
        .str.strip()
    )

    # Convert numerical columns safely
    numerical_columns = [
        "Baseline Flood",
        "PPO Flood",
        "Reduction",
        "PPO Depth",
        "Pump Use"
    ]

    for column in numerical_columns:

        out[column] = pd.to_numeric(
            out[column],
            errors="coerce"
        )

    # Remove invalid rows
    out = out.dropna(
        subset=[
            "Storm",
            "Baseline Flood",
            "PPO Flood",
            "Reduction",
            "PPO Depth",
            "Pump Use"
        ]
    )

    # Keep only the three dashboard storms
    out = out[
        out["Storm"].isin(
            [
                "MODERATE",
                "HEAVY",
                "EXTREME"
            ]
        )
    ]

    # Remove accidental duplicate storm rows
    out = (
        out
        .drop_duplicates(
            subset=["Storm"],
            keep="last"
        )
        .reset_index(drop=True)
    )

    # Put storms in correct order
    storm_order = {
        "MODERATE": 0,
        "HEAVY": 1,
        "EXTREME": 2
    }

    out["_order"] = (
        out["Storm"]
        .map(storm_order)
    )

    out = (
        out
        .sort_values("_order")
        .drop(columns="_order")
        .reset_index(drop=True)
    )

    return out


# ============================================================
# MUMBAI NORMALIZATION
# ============================================================

def normalize_mumbai(df: pd.DataFrame) -> pd.DataFrame:

    required_columns = [
        "storm",
        "controller",
        "total_flooding_volume",
        "max_network_depth",
        "pump_on_percentage",
    ]

    missing_columns = [
        column
        for column in required_columns
        if column not in df.columns
    ]

    if missing_columns:

        raise ValueError(
            "Mumbai results file is missing columns: "
            f"{missing_columns}. "
            f"Found: {list(df.columns)}"
        )

    work = df.copy()

    work["storm"] = (
        work["storm"]
        .astype(str)
        .str.upper()
        .str.strip()
    )

    work["controller"] = (
        work["controller"]
        .astype(str)
        .str.upper()
        .str.strip()
    )

    rows = []

    for storm in work["storm"].unique():

        storm_rows = work[
            work["storm"] == storm
        ]

        baseline_rows = storm_rows[
            storm_rows["controller"] == "OFF"
        ]

        ppo_rows = storm_rows[
            storm_rows["controller"] == "PPO"
        ]

        if baseline_rows.empty or ppo_rows.empty:
            continue

        baseline = baseline_rows.iloc[0]
        ppo = ppo_rows.iloc[0]

        baseline_flood = float(
            baseline["total_flooding_volume"]
        )

        ppo_flood = float(
            ppo["total_flooding_volume"]
        )

        if baseline_flood > 0:

            reduction = (
                (
                    baseline_flood
                    - ppo_flood
                )
                / baseline_flood
            ) * 100.0

        else:

            reduction = 0.0

        rows.append(
            {
                "Storm": storm,
                "Baseline Flood": baseline_flood,
                "PPO Flood": ppo_flood,
                "Reduction": reduction,
                "PPO Depth": float(
                    ppo["max_network_depth"]
                ),
                "Pump Use": float(
                    ppo["pump_on_percentage"]
                ),
            }
        )

    return pd.DataFrame(rows)


# ============================================================
# CITY CONFIGURATION
# ============================================================

CITY_CONFIG = {

    "Chennai": {

        "regions": {

            "Velachery & Pallikaranai": {

                "results_file":
                    RESULTS_DIR /
                    "multi_storm_results.csv",

                "normalize":
                    normalize_chennai,

                "title":
                    "Velachery & Pallikaranai Basin",

                "description":
                    (
                        "Critical flood hotspot draining "
                        "towards Pallikaranai Marshland."
                    ),

                "eval_command":
                    "python multi_storm_test.py velachery",
            },

            "Adyar Coastal": {

                "results_file":
                    RESULTS_DIR /
                    "multi_storm_results.csv",

                "normalize":
                    normalize_chennai,

                "title":
                    "Adyar Coastal Basin",

                "description":
                    (
                        "Coastal drainage region around the "
                        "Adyar River and southern Chennai coast."
                    ),

                "eval_command":
                    "python multi_storm_test.py adyar",
            },
        },
    },

    "Mumbai": {

        "regions": {

            "Hindmata": {

                "results_file":
                    RESULTS_DIR /
                    "mumbai_hindmata_ppo_evaluation.csv",

                "normalize":
                    normalize_mumbai,

                "title":
                    "Hindmata Basin",

                "description":
                    (
                        "Chronic flooding hotspot in central Mumbai, "
                        "draining towards the Hindmata pumping station."
                    ),

                "eval_command":
                    "python multi_storm_test_mumbai.py hindmata",
            },
        },
    },
}


# ============================================================
# CUSTOM CSS
# ============================================================

st.markdown(
    """
    <style>

    .main-title {
        font-size: 40px;
        font-weight: 800;
        margin-bottom: 5px;
    }

    .subtitle {
        font-size: 18px;
        color: #777777;
        margin-bottom: 20px;
    }

    div[data-testid="stMetric"] {
        background-color: rgba(128, 128, 128, 0.08);
        border-radius: 12px;
        padding: 15px;
        border: 1px solid rgba(128, 128, 128, 0.15);
    }

    </style>
    """,
    unsafe_allow_html=True
)


# ============================================================
# LOAD RESULTS
# ============================================================
#
# IMPORTANT:
# Do NOT use st.cache_data here.
#
# Your multi_storm_test.py overwrites
# multi_storm_results.csv after every run.
#
# Reading the file directly guarantees that the dashboard
# displays the latest saved evaluation.
# ============================================================

def load_results(results_file):

    path = Path(results_file)

    if not path.exists():
        return None

    try:

        df = pd.read_csv(path)

        return df

    except Exception as e:

        st.error(
            f"Could not read results file: {e}"
        )

        return None


# ============================================================
# HEADER
# ============================================================

st.markdown(
    """
    <div class="main-title">
        🌊 Urban Flood Control Dashboard
    </div>
    """,
    unsafe_allow_html=True
)

st.markdown(
    """
    <div class="subtitle">
        SWMM Hydraulic Simulation + PPO Intelligent Pump Control
    </div>
    """,
    unsafe_allow_html=True
)

st.divider()


# ============================================================
# SIDEBAR
# ============================================================

st.sidebar.title("🌊 Flood Control")

st.sidebar.markdown(
    "### Simulation Controls"
)


# ============================================================
# CITY SELECTOR
# ============================================================

city = st.sidebar.selectbox(
    "City",
    list(CITY_CONFIG.keys())
)


# ============================================================
# REGION SELECTOR
# ============================================================

city_regions = CITY_CONFIG[city]["regions"]

region = st.sidebar.selectbox(
    "Study Region",
    list(city_regions.keys())
)

region_config = city_regions[region]


# ============================================================
# STORM SELECTOR
# ============================================================

storm = st.sidebar.selectbox(
    "Storm Scenario",
    [
        "MODERATE",
        "HEAVY",
        "EXTREME"
    ]
)


# ============================================================
# REFRESH BUTTON
# ============================================================

st.sidebar.divider()

if st.sidebar.button(
    "🔄 Refresh Results",
    use_container_width=True
):

    st.rerun()


# ============================================================
# MODEL INFORMATION
# ============================================================

st.sidebar.divider()

st.sidebar.markdown(
    "### Model Information"
)

st.sidebar.write(
    "**Hydraulic Model:** SWMM"
)

st.sidebar.write(
    "**Control Algorithm:** PPO"
)

st.sidebar.write(
    "**Control Variable:** Pump"
)

st.sidebar.write(
    "**Storm Scenarios:** 3"
)

st.sidebar.write(
    f"**Cities:** {len(CITY_CONFIG)}"
)

st.sidebar.write(
    "**Study Regions:** "
    f"{sum(len(c['regions']) for c in CITY_CONFIG.values())}"
)


# ============================================================
# RESULTS FILE INFORMATION
# ============================================================

st.sidebar.divider()

st.sidebar.caption(
    "Results file:"
)

st.sidebar.caption(
    str(region_config["results_file"])
)


st.sidebar.divider()

st.sidebar.info(
    "Results shown here are simulation/evaluation "
    "results. They are not real-time flood forecasts."
)


# ============================================================
# LOAD RESULTS
# ============================================================

raw_df = load_results(
    region_config["results_file"]
)


if raw_df is None:

    st.error(
        f"❌ Results file for "
        f"{city} — {region} was not found."
    )

    st.markdown(
        "Run the evaluation first:"
    )

    st.code(
        region_config["eval_command"],
        language="powershell"
    )

    st.markdown(
        "The dashboard expects the file:"
    )

    st.code(
        str(region_config["results_file"]),
        language="text"
    )

    st.stop()


# ============================================================
# NORMALIZE RESULTS
# ============================================================

try:

    results_df = region_config["normalize"](
        raw_df
    )

except ValueError as e:

    st.error(
        f"❌ {e}"
    )

    st.stop()


if results_df.empty:

    st.error(
        f"❌ No usable rows were found in "
        f"the results file for "
        f"{city} — {region}."
    )

    st.stop()


# ============================================================
# VERIFY STORMS
# ============================================================

available_storms = set(
    results_df["Storm"]
)


if storm not in available_storms:

    st.error(
        f"❌ {storm} storm result was not "
        f"found in the current results file."
    )

    st.write(
        "Available storms:"
    )

    st.write(
        sorted(available_storms)
    )

    st.stop()


# ============================================================
# GET SELECTED STORM
# ============================================================

selected_rows = results_df[
    results_df["Storm"] == storm
]


if selected_rows.empty:

    st.error(
        f"❌ No {storm} storm result was found "
        f"for {city} — {region}."
    )

    st.stop()


# Use the latest row if duplicates somehow exist
result = selected_rows.iloc[-1]


# ============================================================
# REGION HEADER
# ============================================================

st.subheader(
    f"{city} — {region_config['title']}"
)

st.caption(
    region_config["description"]
)

st.markdown(
    f"### 📊 {storm.title()} Storm Performance"
)


# ============================================================
# GET VALUES
# ============================================================

baseline_flood = float(
    result["Baseline Flood"]
)

ppo_flood = float(
    result["PPO Flood"]
)

reduction = float(
    result["Reduction"]
)

ppo_depth = float(
    result["PPO Depth"]
)

pump_use = float(
    result["Pump Use"]
)


# ============================================================
# KPI ROW
# ============================================================

c1, c2, c3 = st.columns(3)

c1.metric(
    "Baseline Flooding",
    f"{baseline_flood:.3f}"
)

c2.metric(
    "PPO Flooding",
    f"{ppo_flood:.3f}"
)

c3.metric(
    "Flood Reduction",
    f"{reduction:.2f}%"
)


# ============================================================
# SECOND KPI ROW
# ============================================================

c4, c5 = st.columns(2)

c4.metric(
    "PPO Maximum Depth",
    f"{ppo_depth:.3f}"
)

c5.metric(
    "PPO Pump Usage",
    f"{pump_use:.2f}%"
)


st.divider()


# ============================================================
# FLOOD COMPARISON
# ============================================================

st.markdown(
    f"### 📉 {storm.title()} Storm — Flood Comparison"
)

chart_df = pd.DataFrame(
    {
        "Controller": [
            "Baseline",
            "PPO"
        ],

        "Flooding": [
            baseline_flood,
            ppo_flood
        ],
    }
).set_index("Controller")


st.bar_chart(
    chart_df,
    use_container_width=True
)


st.divider()


# ============================================================
# MULTI-STORM PERFORMANCE TABLE
# ============================================================

st.markdown(
    "### 🌧️ Multi-Storm Performance"
)

table_df = results_df[
    [
        "Storm",
        "Baseline Flood",
        "PPO Flood",
        "Reduction",
        "PPO Depth",
        "Pump Use"
    ]
].copy()


table_df = table_df.rename(
    columns={
        "Reduction":
            "Flood Reduction (%)",

        "PPO Depth":
            "PPO Max Depth",

        "Pump Use":
            "Pump Usage (%)"
    }
)


st.dataframe(
    table_df,
    use_container_width=True,
    hide_index=True
)


st.divider()


# ============================================================
# MULTI-STORM FLOOD GRAPH
# ============================================================

st.markdown(
    "### 📊 Flooding Across Storm Intensities"
)

flood_graph = results_df[
    [
        "Storm",
        "Baseline Flood",
        "PPO Flood"
    ]
].copy()


flood_graph = flood_graph.set_index(
    "Storm"
)


st.bar_chart(
    flood_graph,
    use_container_width=True
)


st.divider()


# ============================================================
# FLOOD REDUCTION GRAPH
# ============================================================

st.markdown(
    "### 📈 PPO Flood Reduction"
)

reduction_graph = results_df[
    [
        "Storm",
        "Reduction"
    ]
].copy()


reduction_graph = reduction_graph.set_index(
    "Storm"
)


st.bar_chart(
    reduction_graph,
    use_container_width=True
)


st.divider()


# ============================================================
# PUMP USAGE GRAPH
# ============================================================

st.markdown(
    "### ⚙️ PPO Pump Usage"
)

pump_graph = results_df[
    [
        "Storm",
        "Pump Use"
    ]
].copy()


pump_graph = pump_graph.set_index(
    "Storm"
)


st.bar_chart(
    pump_graph,
    use_container_width=True
)


st.divider()


# ============================================================
# CURRENT SCENARIO STATUS
# ============================================================

st.markdown(
    "### 🚦 Current Scenario Status"
)


if reduction >= 70:

    st.success(
        f"✅ PPO achieved "
        f"{reduction:.2f}% flood reduction "
        f"during the {storm.lower()} storm."
    )

elif reduction >= 40:

    st.warning(
        f"⚠️ PPO achieved "
        f"{reduction:.2f}% flood reduction "
        f"during the {storm.lower()} storm."
    )

else:

    st.error(
        f"❌ PPO achieved "
        f"{reduction:.2f}% flood reduction "
        f"during the {storm.lower()} storm."
    )


# ============================================================
# PUMP STATUS
# ============================================================

st.info(
    f"PPO pump usage during the "
    f"{storm.lower()} storm: "
    f"{pump_use:.2f}%."
)


# ============================================================
# CURRENT SCENARIO SUMMARY
# ============================================================

st.markdown(
    "### 📋 Current Scenario Summary"
)


summary_df = pd.DataFrame(
    {
        "Parameter": [
            "City",
            "Study Region",
            "Storm Scenario",
            "Baseline Flooding",
            "PPO Flooding",
            "Flood Reduction",
            "PPO Maximum Depth",
            "PPO Pump Usage"
        ],

        "Value": [
            city,
            region,
            storm,
            f"{baseline_flood:.3f}",
            f"{ppo_flood:.3f}",
            f"{reduction:.2f}%",
            f"{ppo_depth:.3f}",
            f"{pump_use:.2f}%"
        ]
    }
)


st.dataframe(
    summary_df,
    use_container_width=True,
    hide_index=True
)


# ============================================================
# FOOTER
# ============================================================

st.divider()

st.caption(
    "Urban Flood Control | SWMM + PPO Simulation"
)

st.caption(
    "Model outputs are simulation results and should "
    "not be interpreted as real-time operational instructions."
)
